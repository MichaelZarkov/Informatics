#include "person.h"
#include "car.h"
#include "parking.h"


int main (){

	return 0;
}
