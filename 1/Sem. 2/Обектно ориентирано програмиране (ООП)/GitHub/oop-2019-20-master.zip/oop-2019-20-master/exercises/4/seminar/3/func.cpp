#include <iostream>
using namespace std;

int a = 5;

void printA(int a) {
    cout<< a<< endl;
}

int main () {
    printA(5);

    return 0;
}
