#ifndef UTILITY
#define UTILITY

namespace utility {
    int gcd(int a, int b);
}

#endif // !UTILITY