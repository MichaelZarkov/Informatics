#ifndef NUMBER
    struct Number {
        int val;
    };

    Number operator+(const Number a, const Number b);
#endif
