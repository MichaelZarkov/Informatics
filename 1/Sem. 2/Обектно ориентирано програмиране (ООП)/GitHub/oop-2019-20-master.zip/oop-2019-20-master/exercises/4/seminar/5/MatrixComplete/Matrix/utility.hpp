#ifndef UTILITY
#define UTILITY

namespace Utility {
    int gcdHelper(int a, int b);
    int gcd(int a, int b);
}

#endif // UTILITY
