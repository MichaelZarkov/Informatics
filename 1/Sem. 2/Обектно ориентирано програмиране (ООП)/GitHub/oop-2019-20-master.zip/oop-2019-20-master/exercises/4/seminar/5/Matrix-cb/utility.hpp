#ifndef UTILITY
#define UTILITY

namespace Utility {
    int gcd(int a, int b);
}

#endif // UTILITY
