#include "StudentContainer.h"

StudentContainer::StudentContainer(Student s)
{
    //ctor
}

StudentContainer::~StudentContainer()
{
    //dtor
}
