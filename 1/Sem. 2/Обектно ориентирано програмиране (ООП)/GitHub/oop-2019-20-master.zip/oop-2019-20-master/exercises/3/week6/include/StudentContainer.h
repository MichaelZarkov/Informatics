#ifndef STUDENTCONTAINER_H
#define STUDENTCONTAINER_H
#include "Student.h"

class StudentContainer
{
    public:
        StudentContainer(Student s);
        virtual ~StudentContainer();

    protected:

    private:
};

#endif // STUDENTCONTAINER_H
