#include<iostream>
#include<cstring>
#include"Student.h"
using namespace std;

int main(){
    //int s;
    //int (n = (s = 3));
    Student s1,s2;
    s1 = s2;
    return 0;
}
