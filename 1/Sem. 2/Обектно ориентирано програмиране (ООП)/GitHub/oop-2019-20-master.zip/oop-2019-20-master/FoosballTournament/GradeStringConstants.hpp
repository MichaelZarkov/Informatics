#pragma once

static class GradeStringsConstants
{
public:
	static const char* INTERN;
	static const char* CTO;
};

const char* GradeStringsConstants::INTERN = "Intern";
const char* GradeStringsConstants::CTO = "Chief Technical Officer";