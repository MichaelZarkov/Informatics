#pragma once

enum class Grade
{
	Intern = 0,
	JuniorDev,
	MediumDev,
	SeniorDev,
	CTO,
	CEO,
	InvalidGrade = -1
};


