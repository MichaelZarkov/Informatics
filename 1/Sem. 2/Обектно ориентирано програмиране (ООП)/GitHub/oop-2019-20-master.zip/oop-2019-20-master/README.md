# oop-2019-20
Код към лекциите и упражненията на курса по Обектно-ориентирано програмиране на спец. Информатика, 2019/20 г. 

## Структура на хранилището

 * [__lectures__](https://github.com/triffon/oop-2019-20/tree/master/lectures) - Материалите от лекциите.
 
 * [__exercises__](https://github.com/triffon/oop-2019-20/tree/master/exercises) - Папки с материали от семинарите.
    * [__Първа група__](https://github.com/triffon/oop-2019-20/tree/master/exercises/1)
    * [__Втора група__](https://github.com/triffon/oop-2019-20/tree/master/exercises/2)
    * [__Трета група__](https://github.com/triffon/oop-2019-20/tree/master/exercises/3)
    * [__Четвърта група__](https://github.com/triffon/oop-2019-20/tree/master/exercises/4)
    * [__Пета група__](https://github.com/triffon/oop-2019-20/tree/master/exercises/5)
    * [__Шеста група__](https://github.com/triffon/oop-2019-20/tree/master/exercises/6)
    
 * [__labs__](https://github.com/triffon/oop-2019-20/tree/master/labs) - Папки с материалите от практикумите.
    * [__Първа група__](https://github.com/triffon/oop-2019-20/tree/master/labs/1)
    * [__Втора група__](https://github.com/triffon/oop-2019-20/tree/master/labs/2)
    * [__Трета група__](https://github.com/triffon/oop-2019-20/tree/master/labs/3)
    * [__Четвърта група__](https://github.com/triffon/oop-2019-20/tree/master/labs/4)
    * [__Пета група__](https://github.com/triffon/oop-2019-20/tree/master/labs/5)
    * [__Шеста група__](https://github.com/triffon/oop-2019-20/tree/master/labs/6)


    
## Дистанционни Упражнения

 * [__Шеста група__](https://drive.google.com/drive/folders/0B2mK2PokkjqTfmk2ZjhhVDBwNWVhVEd6bnU4SFlES2loQ0hhcHVRSGVsZDA2Q0ZjNkY0dXM?usp=sharing)
