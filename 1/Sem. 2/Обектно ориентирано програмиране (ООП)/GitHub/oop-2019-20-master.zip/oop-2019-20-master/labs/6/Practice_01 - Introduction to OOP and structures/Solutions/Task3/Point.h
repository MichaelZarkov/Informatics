//
// Created by yasen on 2/22/20.
//

#ifndef TASK3_POINT_H
#define TASK3_POINT_H


struct Point {
    double x, y;
};

void enterPoint(Point&);
void printPoint(const Point&);

#endif //TASK3_POINT_H
