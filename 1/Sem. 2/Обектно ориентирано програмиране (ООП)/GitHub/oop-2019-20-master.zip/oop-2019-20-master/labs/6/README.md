# Практикум 6 група

## [Practice_01](https://github.com/triffon/oop-2019-20/tree/master/labs/6/Practice_01)
Задачи за работа със структури.

## [Practice_02](https://github.com/triffon/oop-2019-20/tree/master/labs/6/Practice_02)
Задачи за работа с класове - constructors, setters, getters, methods.

## [Practice_03](https://github.com/triffon/oop-2019-20/tree/master/labs/6/Practice_03)
Задачи за работа с класове - динамична памет, голяма четворка.

---