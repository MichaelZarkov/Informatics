#include "Beer.h"

int main()
{

    Beer beer1("Stella Artois", 500);

    return 0;
}
