
#include <iostream>
#include "MonthlyPlanner.h"

int main()
{

	Task t1("desc1", 1, 1);
	Task t2("desc2", 2, 2);
	Task t3("desc3", 3, 3);


	MonthlyPlanner MP(3);
	
	MP.addTask(t1, 11, "10:00");
	MP.addTask(t2, 11, "20:00");
	MP.addTask(t3, 11, "15:00");

	MP.printUnfin(11);

}