

#include "MonthlyPlanner.h"

MonthlyPlanner::MonthlyPlanner(size_t month) {
	if (month < 1)
		this->month = 1;

	if (month > 12)
		this->month = 12;
}
MonthlyPlanner::~MonthlyPlanner() {

}


size_t MonthlyPlanner::getMonth() const { return month; }

void MonthlyPlanner::addTask(const Task& task, size_t day, const char* startHour) {
	// Check min
	if (!valideteHour(startHour, task.getDuration()) || day > 30)
		return;
	
	size_t i = 0;
	for (; i < taskCount; ++i) {
		if (day == whichDay[i] && isOverlap(task, startHour, i))
			break;
	}

	if (i >= taskCount) {
		++taskCount;
		Task* temptask = new Task[taskCount];
		size_t* tempstarttime = new size_t[taskCount];
		size_t* tempwhichday = new size_t[taskCount];

		for (size_t k = 0; k < taskCount - 1; ++k) {
			temptask[k] = tasks[k];
			tempstarttime[k] = startTime[k];
			tempwhichday[k] = whichDay[k];
		}
		
		temptask[taskCount - 1] = task;
		tempstarttime[taskCount - 1] = convertToMin(startHour);
		tempwhichday[taskCount - 1] = day;

		delete[] tasks;
		delete[] startTime;
		delete[] whichDay;

		tasks = temptask;
		startTime = tempstarttime;
		whichDay = tempwhichday;
	}
	else if (1 == task.higherPriority(tasks[i])) {
		Task* temptask = new Task[taskCount];
		size_t* tempstarttime = new size_t[taskCount];
		size_t* tempwhichday = new size_t[taskCount];

		for (size_t k = 0; k < i; ++k) {
			temptask[k] = tasks[k];
			tempstarttime[k] = startTime[k];
			tempwhichday[k] = whichDay[k];
		}

		temptask[i] = task;
		tempstarttime[i] = convertToMin(startHour);
		tempwhichday[i] = day;

		for (size_t k = i + 1; k < taskCount; ++k) {
			temptask[k] = tasks[k];
			tempstarttime[k] = startTime[k];
			tempwhichday[k] = whichDay[k];
		}

		delete[] tasks;
		delete[] startTime;
		delete[] whichDay;

		tasks = temptask;
		startTime = tempstarttime;
		whichDay = tempwhichday;
	}


	return;
}

void MonthlyPlanner::printUnfin(size_t day) {
	for (size_t i = 0; i < taskCount; ++i) {
		if (day == whichDay[i] && !tasks[i].getStatus()) {
			tasks[i].print();
		}
	}
}


//private-------------------------------------------------------------------------------

bool MonthlyPlanner::valideteHour(const char* startH, size_t duration) {
	if (strlen(startH) != 5 || notDig(startH[0]) || notDig(startH[1]) || startH[2] != ':' || notDig(startH[3]) || startH[3] > '5' || notDig(startH[4]))
		return false;

	// Convert to minutes.
	size_t minutes = convertToMin(startH);
	if (minutes + duration >= 1440)		// There are 1440 minutes in 24 hours.
		return false;

	return true;
}

size_t MonthlyPlanner::convertToMin(const char* H) {
	return (H[0] - 48) * 600 + (H[1] - 48) * 60 + (H[3] - 48) * 10 + H[4] - 48;
}

// Returns true if start or end of 'task' is between start and end of 'tasks[i]'
bool MonthlyPlanner::isOverlap(const Task& task, const char* startH, size_t i) {
	size_t min = convertToMin(startH);
	if ((startTime[i] <= min && min <= startTime[i] + tasks[i].getDuration()) ||
		(startTime[i] <= min + task.getDuration() && min + task.getDuration() <= startTime[i] + tasks[i].getDuration()))
		return true;

	return false;
}

// Returns true if 'c' is not a digit.
bool MonthlyPlanner::notDig(char c) {
	return (c < 48 || 57 < c);
}