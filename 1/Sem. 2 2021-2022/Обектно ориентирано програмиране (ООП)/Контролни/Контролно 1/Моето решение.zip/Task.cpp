

#include "Task.h"
#pragma warning(disable : 4996)


const size_t Task::MAX_PRIORITY = 100;

Task::Task(){}
Task::Task(const char* descr, size_t prior, size_t dur) {
	validateName(descr);

	setPriority(prior);
	
	setDuration(dur);
}
Task::Task(const Task& other) {
	priority = other.priority;
	duration = other.duration;

	description = new char[strlen(other.description) + 1];
	strcpy(description, other.description);
}
Task& Task::operator=(const Task& other) {
	if (this != &other && !this->description) {
		validateName(other.description);
		setDuration(other.duration);
		setPriority(other.priority);
	}

	return *this;
}
Task::~Task() {
	delete[] description;
}

const char* Task::getDescription() const { return description; }
size_t Task::getPriority() const { return priority; }
size_t Task::getDuration() const { return duration; }
bool Task::getStatus() const { return status; }

void Task::setPriority(size_t prior) {
	if (prior > MAX_PRIORITY)
		prior = MAX_PRIORITY;

	priority = prior;
}
void Task::setDuration(size_t dur) {
	if (dur == 0)	// Nothing can be done in zero time!
		dur = 1;

	duration = dur;
}
void Task::setStatus(bool stat) {
	if (!stat)
		return;

	status = true;
}

// Returns -1 if 'this' is with lower prior. than 'other',
//			0 if they are with equal prior.,
//			1 if 'this' is with higher prior. than 'other'.
int Task::higherPriority(const Task& other) const {
	if (priority > other.priority)
		return 1;
	else if (priority < other.priority)
		return -1;
	else if (duration < other.duration)
		return 1;
	else if (duration > other.duration)
		return -1;

	return 0;
}

void Task::print() {
	std::cout << description << "\n"
		<< priority << "\n"
		<< duration << "\n"
		<< status;
}

//private------------------------------------------------------------------------


bool Task::validateName(const char* descr) {
	size_t len = strlen(descr);
	if (!descr || !len) {
		description = new char[10];
		strcpy(description, "UNDEFINED");
		return false;
	}

	description = new char[len + 1];
	strcpy(description, descr);
	
	return true;
}
