

#pragma once
#include <cstring>
#include <iostream>

class Task {
private:

	char* description{ nullptr };		// If nullptr the task is considered not initialized.
	size_t priority{ 0 };
	static const size_t MAX_PRIORITY;
	size_t duration { 0 };
	bool status { false };

public:

	Task();
	Task(const char* descr, size_t prior, size_t dur);
	Task(const Task&);
	Task& operator=(const Task&);
	~Task();

	const char* getDescription() const;
	size_t getPriority() const;
	size_t getDuration() const;
	bool getStatus() const;

	void setPriority(size_t);
	void setDuration(size_t);
	void setStatus(bool);

	int higherPriority(const Task&) const;

	void print();

private:

	bool validateName(const char*);

};
