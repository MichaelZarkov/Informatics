

#pragma once
#include "Task.h"

class MonthlyPlanner {
private:

	Task* tasks{ nullptr };
	size_t* startTime{ nullptr };
	size_t* whichDay{ nullptr };
	size_t taskCount{ 0 };
	size_t month{ 1 };

public:
	
	MonthlyPlanner(size_t month);
	MonthlyPlanner& operator=(const MonthlyPlanner&) = delete;
	~MonthlyPlanner();

	size_t getMonth() const;

	void addTask(const Task&, size_t, const char*);
	void printUnfin(size_t);

private:

	bool valideteHour(const char*, size_t duration);
	size_t convertToMin(const char*);
	bool isOverlap(const Task& task, const char* startH, size_t i);
	bool notDig(char);
};
