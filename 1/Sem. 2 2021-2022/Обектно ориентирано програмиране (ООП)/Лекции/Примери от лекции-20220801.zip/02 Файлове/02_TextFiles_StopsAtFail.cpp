﻿#include <fstream>
#include <iomanip>
#include <iostream>

// Потоците не могат да бъдат предавани по стойност, не могат да бъдат копирани!
void rewind(std::ifstream& inputFile);
void showNumbers(std::ifstream& inputFile);

int main()
{
	// Добре е след отваряне на файла да се провери дали операцията е успешна.
	std::ifstream inputFile("numbers.txt", std::ios::in);
	if (!inputFile.is_open())
	{
		std::cout << "The file cannot be opened for reading!\n";
	}

	showNumbers(inputFile);

	if (!inputFile.eof())
	{
		std::cout << "The end of file has not been reached!\n";
	}

	inputFile.close();

	return 0;
}

void rewind(std::ifstream& inputFile)
{
	inputFile.clear();
	inputFile.seekg(0, std::ios::beg);
}

void showNumbers(std::ifstream& inputFile)
{
	rewind(inputFile);

	int number = 0;
	// цикъл ще прекъсне, ако потокът изпадне в състояние,
	// различно от good
	while (inputFile >> number)
	{
		std::cout << number << ' ';
	}
}

