#include <fstream>
#include <iostream>

using std::cerr;
using std::ios;
using std::fstream;
using std::streampos;

#include "address.h"
#include "student.h"

void generateStudentFile()
{
    Student students[5];

    for (int i = 0; i < 5; ++i)
    {
        students[i].name = nullptr;
        readStudent(students[i]);
    }

    fstream file("students.dat", ios::out | ios::binary | ios::trunc);
    if (!file)
    {
        cerr << "Problem with the file...";
        return;
    }

    for (int i = 0; i < 5; ++i)
    {
        if (!store(students[i], file)) 
            break;
    }

    file.close();
}

void printStudentsFromFile()
{
    Student s;
    s.name = nullptr;

    fstream file("students.dat", ios::in | ios::binary);
    if (!file)
    {
        std::cerr << "The file cannot be opened!\n";
        return;
    }

    while (load(s, file))
        printStudent(s);

    file.close();
}

void toUpper(char* text)
{
    while (*text)
    {
        if (*text >= 'a' && *text <= 'z')
        {
            *text = *text - 'a' + 'A';
        }
        ++text;
    }
}

void changeNameOfAllInf()
{
    Student s;
    s.name = nullptr;
    fstream file("students.dat", ios::in | ios::out | ios::binary);
    
    if (!file) return;

    streampos begin = 0;
    while (load(s, file))
    {
        if (s.program == INFORMATICS)
        {
            toUpper(s.name);
            streampos end = file.tellg();
            
            file.seekp(begin, ios::beg);
            store(s, file);
            
            file.seekg(end, ios::beg);
        }

        begin = file.tellg();
    }

    file.close();
}

int main()
{
    generateStudentFile();
    printStudentsFromFile();
    changeNameOfAllInf();
    printStudentsFromFile();

    return 0;
}
