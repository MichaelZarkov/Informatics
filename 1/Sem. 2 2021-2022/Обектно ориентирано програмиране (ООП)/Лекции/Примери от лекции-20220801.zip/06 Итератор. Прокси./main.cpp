#include "SortedArray.h"

#include <iostream>

int main()
{
	SortedArray arr(5);
	arr += 1;
	arr += 3;
	arr += 5;
	arr += 2;
	arr += 0;

	for (SortedArray::Iterator it = arr.begin(); it != arr.end(); ++it) 
	{
		std::cout << *it << " ";
	}
	std::cout << std::endl;
	
	std::cout << arr(1) << '\n';

	arr[2] = 0;
	arr[0] = 18;
	arr[2] = 11;
	
	std::cout << arr(1) << '\n';
	
	for (SortedArray::Iterator it = arr.begin(); it != arr.end(); ++it) 
	{
		std::cout << *it << " ";
	}
	std::cout << '\n';
	
	for (int i = 0; i < 5; ++i)
		std::cout << arr[i] << ' ';
	std::cout << '\n';
	
	std::cout << arr(2) << '\n';
	std::cout << arr(3) << '\n';
	std::cout << std::endl;
	
	return 0;
}

