#include "SortedArray.h"

SortedArray::SortedArray(size_t cap) :
	capacity(cap),
	arr_size(0),
	data(nullptr)
{
	data = new int[capacity];
}

SortedArray::SortedArray(const SortedArray& other) :
	capacity(other.capacity),
	arr_size(other.arr_size)
{
	data = new int[capacity];
	for (size_t i = 0; i < arr_size; ++i) 
	{
		data[i] = other.data[i];
	}
}

SortedArray::SortedArray(SortedArray&& other) noexcept :
	capacity(other.capacity),
	arr_size(other.arr_size)
{
	data = other.data;
	other.data = nullptr;
}

SortedArray::~SortedArray()
{
	delete[] data;
}

SortedArray& SortedArray::operator= (const SortedArray& other)
{
	if (&other != this)
	{
		if (capacity < other.arr_size) 
		{
			throw std::overflow_error("The array 'other' too long to be assigned!");
		}
		
		arr_size = other.arr_size;
		for (size_t i = 0; i < arr_size; ++i) 
		{
			data[i] = other.data[i];
		}
	}

	return *this;
}

size_t SortedArray::size() const
{
	return arr_size;
}

SortedArray SortedArray::operator+ (int elem) const
{
	SortedArray result(*this);
	return result += elem;
}

SortedArray& SortedArray::operator+= (int elem)
{
	addElem(elem);
	return *this;
}

SortedArray& SortedArray::operator+= (const SortedArray& other)
{
	if (arr_size + other.arr_size >= capacity) 
	{
		throw std::overflow_error("Array is Full!");
	}

	//This approach is too slow. Should be a merge operation!
	for (size_t i = 0; i < other.arr_size; ++i) 
	{
		addElem(other.data[i]);
	}
	
	return *this;
}

//find
int SortedArray::operator() (int number)
{
	size_t	begin = 0, 
			end = arr_size;

	while (begin < end)
	{
		size_t mid = (begin + end) / 2;
	
		if (data[mid] == number)
			return mid;
		
		if (data[mid] < number)
			begin = mid + 1;
		else
			end = mid;
	}

	return -1;
}

//sub-array
SortedArray SortedArray::operator() (size_t begin, size_t end)
{
	if (begin > end) 
	{
		throw std::invalid_argument("Begin after end");
	}

	if (end > arr_size) 
	{
		throw std::out_of_range("Bad end index");
	}
	
	SortedArray result(end - begin);
	for (size_t i = 0; i < end - begin; ++i)
	{
		result[i] = data[i + begin];
	}
	
	return result;
}

int SortedArray::operator[](size_t index) const
{
	if (index > arr_size) 
	{
		//1) return 0; // �������� ����� �� 0
		throw std::out_of_range("Index too large");
	}
	
	return data[index];
}

SortedArray::SAProxy SortedArray::operator[](size_t index)
{
	if (index > arr_size) 
	{
		throw std::out_of_range("Index too large");
	}
	
	return SAProxy(*this, index);
}

SortedArray::Iterator SortedArray::begin()
{
	return Iterator(data);
}

SortedArray::Iterator SortedArray::end()
{
	return Iterator(data + arr_size);
}

void SortedArray::addElem(int elem)
{
	if (arr_size == capacity)
	{
		throw std::overflow_error("Array is Full!");
	}

	data[arr_size++] = elem;
	moveFront(elem, arr_size - 1);
}

void SortedArray::moveFront(int elem, int pos)
{
	int i = pos;
	while (i > 0 && data[i - 1] > elem)
	{
		data[i] = data[i - 1];
		--i;
	}

	data[i] = elem;
}

void SortedArray::moveBack(int elem, size_t pos)
{
	size_t i = pos;
	while (i < arr_size - 1 && data[i + 1] < elem) 
	{
		data[i] = data[i + 1];
		++i;
	}
	
	data[i] = elem;
}

SortedArray::SAProxy::operator int()
{
	return caller.data[index];
}

SortedArray::SAProxy& SortedArray::SAProxy::operator=(int elem)
{
	int old = caller.data[index];
	caller.data[index] = elem;
	
	if (old > elem) 
		caller.moveFront(elem, index);
	else 
		caller.moveBack(elem, index);
	
	return *this;
}

SortedArray::Iterator& SortedArray::Iterator::operator++()
{
	++ptr;
	return *this;
}

SortedArray::Iterator SortedArray::Iterator::operator++(int)
{
	Iterator current(*this);
	++(*this);
	return current;
}

bool SortedArray::Iterator::operator==(const Iterator& other) const
{
	return ptr == other.ptr;
}

bool SortedArray::Iterator::operator!=(const Iterator& other) const
{
	return !(*this == other);
}

int SortedArray::Iterator::operator*() const
{
	return *ptr;
}

int& SortedArray::Iterator::operator*()
{
	return *ptr;
}
