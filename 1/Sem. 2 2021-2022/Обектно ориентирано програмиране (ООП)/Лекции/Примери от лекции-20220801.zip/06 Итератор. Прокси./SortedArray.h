﻿#pragma once

#ifndef SORTEDARRAY_HEADER_INCLUDED
#define SORTEDARRAY_HEADER_INCLUDED

#include <iostream>
#include <stdexcept>

class SortedArray
{
public:
    // без explicit конструкторът може да се използва 
    // за неявно преобразуване от цяло число към SortedArray
    explicit SortedArray(size_t cap = 32);
    SortedArray(const SortedArray& other);
    // move ctor
    SortedArray(SortedArray&& other) noexcept;

    ~SortedArray();

    SortedArray& operator=(const SortedArray& other);
    // move assignment не е дефиниран,
    // заради const член-данните в класа

    size_t size() const;

    SortedArray operator+ (int elem) const;

    SortedArray& operator+= (int elem);
    SortedArray& operator+= (const SortedArray& other);

    // find
    // елементите са соритирани, използва се двоично търсене
    int operator()(int number);

    // sub-array
    SortedArray operator()(size_t begin, size_t end);

    class SAProxy
    {
        friend class SortedArray;

        public:
            operator int();
            SAProxy& operator= (int elem);

        private:
            SAProxy(SortedArray& caller, size_t idx)
                : caller(caller), index(idx) {}

        private:
            SortedArray& caller;
            size_t index;
    };

    int operator[](size_t index) const;
    // arr[i] = 4;

    SAProxy operator[](size_t index);

    class Iterator 
    {
        friend class SortedArray;

        public:
            Iterator& operator++();
            Iterator operator++(int);

            bool operator == (const Iterator& other)const;
            bool operator != (const Iterator& other)const;

            int operator*() const;

            //проблем с сортирането - може да се развали?!?!?
            int& operator*();

            /* за идеята
            int* operator->()
            {
                return ptr;
            }
            */

        private:
            Iterator(int* data) : ptr(data) {}

        private:
            int* ptr;
    };

    Iterator begin();
    Iterator end();

private:
    void addElem(int elem);
    void moveFront(int elem, int pos);
    void moveBack(int elem, size_t pos);

private:
    const size_t capacity;
    size_t arr_size;
    int* data;
};

#endif // !SORTEDARRAY_HEADER_INCLUDED

