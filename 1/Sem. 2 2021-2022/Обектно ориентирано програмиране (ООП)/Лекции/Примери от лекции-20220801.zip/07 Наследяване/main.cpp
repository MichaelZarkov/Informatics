﻿/* Примерен код за демонстрация на наследяване и наслояване;
   бавози и производни класове.
   ФМИ, ООП 2022
*/

#include "shape.hpp"
#include "rectangle.hpp"
#include "circle.hpp"
#include "filled_circle.hpp"

#include <iostream>
using std::cout;
using std::endl;

void print(const Shape& s)
{
    s.print();
    cout << "Area: " << s.getArea();
    cout << endl;
}

void printCircle(const Circle& c)
{
    cout << "---------------\n";
    c.print();
    cout << "Area: " << c.getArea();
    cout << endl;
    cout << "---------------\n";
}

void inheritanceTest()
{
    Point zero;
    Point point(3, 5);

    cout << "Shape test: " << endl;
    Shape unknown;
    unknown.print();
    unknown.moveWith(point);
    unknown.print();

    cout << "\n\nCircle test: " << endl;
    Circle c(zero, 0);
    print(c);
    printCircle(c);

    cout << "\n\nFilled Circle test: " << endl;
    FilledCircle fc(point, 5, "Black");
    printCircle(fc);
    print(fc);
    fc.print();

    print(Rectangle(zero, point));

}

int main()
{
    try
    {
        inheritanceTest();
    }
    catch (const char* ex)
    {
        std::cerr << "Exception caught: " << ex << std::endl;
    }

    return 0;
}
