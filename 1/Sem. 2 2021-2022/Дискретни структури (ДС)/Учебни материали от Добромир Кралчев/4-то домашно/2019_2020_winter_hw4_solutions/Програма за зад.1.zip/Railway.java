import java.lang.*;
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.util.zip.*;


class TrainConfiguration {

  // ������ ����� ������� �� �� ������� � ����� ������ � ����:
  public String west;   // �������� �� ��������  (�����) ���� �� �������� ������� �� �� �������;
  public String east;   // �������� �� �������� (������) ���� �� �������� ������� �� �� �������;
  public String south;  // �������� �� ����� (�������������) ������� �� �� �������.

  // ����� ��� �� ������ �� ������� R, B, E:
  // R (red) � ��������� �����;
  // B (blue) � ������ �����;
  // E (engine) � �����������.
  // ����� �� ����� ����� �� ����� ����� ������ ���� � ����� ����.
  // � �������� east � west �������� �� �������� �� ����� �� �� (������ ������).
  // � ���� south �������� �� �������� �� ����� �� ����� (������� ������).

  public TrainConfiguration(TrainConfiguration conf) {
    this.east  = conf.east;
    this.west  = conf.west;
    this.south = conf.south;
  }

  public TrainConfiguration(String s) throws IOException {
    if (s == null)
      throw new IOException("Empty configuration string.");
    if (s.length() != 5)
      throw new IOException("Invalid configuration string: length must be 5.");
    String[] strs = new String[3];
    strs[0] = "";
    strs[1] = "";
    strs[2] = "";
    int n = 0;
    int cntE = 0;
    int cntR = 0;
    int cntB = 0;
    for (int k = 0; k < s.length(); k++) {
      char c = s.charAt(k);
      switch (c) {
        case 'E': cntE++; strs[n] = strs[n] + c; break;
        case 'R': cntR++; strs[n] = strs[n] + c; break;
        case 'B': cntB++; strs[n] = strs[n] + c; break;
        case '_': if (++n >= strs.length) throw new IOException("Too many portions of configuration: must be 3."); break;
        default : throw new IOException("Unknown character in configuration: only E, R, B, and underscore allowed.");
      }
    }
    if (n < strs.length - 1)
      throw new IOException("More portions of configuration expected: must be 3.");
    if (cntE != 1 || cntR != 1 || cntB != 1)
      throw new IOException("Invalid configuration: must contain each of letters E, R, B exactly once.");
    east  = strs[0];
    west  = strs[1];
    south = strs[2];
  }

  public String toString() {
    return east + "_" + west + "_" + south;
  }

  public boolean equals(Object obj) {
    if (obj == null) return false;
    if (!(obj instanceof TrainConfiguration)) return false;
    return toString().equals(obj.toString());
  }
}


class TrainConfigurationsWithMovements {
  public TrainConfiguration[] confs;
  public int[] movements;
  // movements.length = max(0, confs.length - 1);
  // null arrays instead of zero lengths.
}


class CarriageEnginePosition {
  public boolean isOnStraightRailway; // �������������: ������� ��� �� ���������� ������ �� ��������
  public double alpha;
  public int offsetX;

  public void assign(CarriageEnginePosition pos) {
    if (pos == null) return;
    this.isOnStraightRailway = pos.isOnStraightRailway;
    this.alpha = pos.alpha;
    this.offsetX = pos.offsetX;
  }

  public boolean equals(Object obj) {
    if (obj == null)
      return false;
    if (!(obj instanceof CarriageEnginePosition))
      return false;
    CarriageEnginePosition data = (CarriageEnginePosition) obj;
    if (data.isOnStraightRailway != this.isOnStraightRailway)
      return false;
    if (isOnStraightRailway)
      return (data.offsetX == this.offsetX);
    else
      return (data.alpha == this.alpha);
  }
}


class TrainPositions {

  public CarriageEnginePosition  blueCarriagePosition;
  public CarriageEnginePosition   redCarriagePosition;
  public CarriageEnginePosition        enginePosition;

  public TrainPositions() {
    blueCarriagePosition = new CarriageEnginePosition();
     redCarriagePosition = new CarriageEnginePosition();
          enginePosition = new CarriageEnginePosition();
  }  
}


class BufferedImageTrain extends BufferedImage {

  public TrainPositions train; // ���������� �� �������� � ����������

  public BufferedImageTrain(int width, int height, int type) {
    super(width, height, type);
    train = new TrainPositions();
  }
}


public class Railway {

  // �������:
  private static final Color bgrColor = Color.WHITE; // ���� �� ����
  private static final Color BLUE   = new Color(80, 120, 255); // �����
  private static final Color RED    = new Color(255,  20, 40); // �������
  private static final Color YELLOW =     Color.       YELLOW; // �����

  // �������:
  private static final int pictureWidth   = 420; // ��������   �� ������ ��������
  private static final int pictureHeight  = 260; // ���������� �� ������ ��������
  private static final int railwayCenterX = 120; // ���������  �� ������� �� ����� �� �����
  private static final int railwayCenterY = 135; // ���������� �� ������� �� ����� �� �����
  private static final int railwayRadius  = 100; // �������� ������ �� ����� �� �����
  private static final int railwayDeltaR  =   5; // ������������� �� ������� � ��������� ������
  private static final int railwayPad     =   2; // ���������� �� �������
  private static final int tPad           =   2; // ���������� �� ����������
  private static final int tDist          =  10; // ������������ ����� ����������
  private static final int railwayLength  = 280; // ��������� �� ������ ������� �� �����

  // ���������� ������:
  private static BufferedImage imgRailway = null;       // �������
  private static BufferedImage imgBridge = null;        // ������

  private static void drawStraightLine(BufferedImage img, int x1, int y1, int x2, int y2, int width, Color clr) {
    int deltaX = x2 - x1;
    int deltaY = y2 - y1;
    for (double t = 0; t <= 1; t += 0.0005) {
      int x = (int) Math.round(t * deltaX + x1);
      int y = (int) Math.round(t * deltaY + y1);
      img.setRGB(x, y, clr.getRGB());
      if (Math.abs(deltaY) > Math.abs(deltaX)) {
        int direction = (deltaY > 0) ? +1 : -1;
        for (int w = 1; w < width; w++)
          img.setRGB(x + direction * w, y, clr.getRGB());
      }
      else {
        int direction = (deltaX > 0) ? -1 : +1;
        for (int w = 1; w < width; w++)
          img.setRGB(x, y + direction * w, clr.getRGB());
      }
    }
  }

  private static void floodFill(BufferedImage img, int x, int y, Color oldColor, Color newColor) {
    floodFill(img, x, y, oldColor.getRGB(), newColor.getRGB());
  }

  private static void floodFill(BufferedImage img, int x, int y, int oldColor, int newColor) {
    if (img.getRGB(x, y) == oldColor) {
      img.setRGB(x, y, newColor);
      try { floodFill(img, x-1, y, oldColor, newColor); } catch(ArrayIndexOutOfBoundsException e) {}
      try { floodFill(img, x+1, y, oldColor, newColor); } catch(ArrayIndexOutOfBoundsException e) {}
      try { floodFill(img, x, y-1, oldColor, newColor); } catch(ArrayIndexOutOfBoundsException e) {}
      try { floodFill(img, x, y+1, oldColor, newColor); } catch(ArrayIndexOutOfBoundsException e) {}
    }
  }

  private static void drawCircle(BufferedImage img, int centerX, int centerY, int radius, int pad, Color clr) {
    double alpha = 0;
    while (alpha < 2 * Math.PI) {
      for (int padR = 0; padR < pad; padR++) {
        int x = (int) Math.round(centerX + (radius + padR) * Math.cos(alpha));
        int y = (int) Math.round(centerY + (radius + padR) * Math.sin(alpha));
        img.setRGB(x, y, clr.getRGB());
      }
      alpha = alpha + 0.0001;
    }
  }

  private static void drawRadii(BufferedImage img, int centerX, int centerY, int intR, int extR, int pad, Color clr) {
    int num = (int) Math.ceil(Math.PI * (intR + extR) / tDist);
    double alphaDist = 2 * Math.PI / num;
    for (; num > 0; num--) {
      double alpha = num * alphaDist;
      int x1 = (int) Math.round(centerX + intR * Math.cos(alpha));
      int y1 = (int) Math.round(centerY + intR * Math.sin(alpha));
      int x2 = (int) Math.round(centerX + extR * Math.cos(alpha));
      int y2 = (int) Math.round(centerY + extR * Math.sin(alpha));
      drawStraightLine(img, x1, y1, x2, y2, pad, clr);
    }
  }

  private static void drawVertT(BufferedImage img, int x1, int x2, int y1, int y2, int padX, Color clr) {
    for (int x = x1; x <= x2; x += tDist) {
      drawStraightLine(img, x, y1, x, y2, padX, clr);
    }
  }

  private static void createRailwayImage() {
    imgRailway = new BufferedImage(pictureWidth, pictureHeight, BufferedImage.TYPE_INT_ARGB);
    Graphics2D g = imgRailway.createGraphics();
    g.setColor(bgrColor);
    g.fillRect(0, 0, pictureWidth, pictureHeight);
    g.setColor(Color.BLACK);
    int intR = railwayRadius - railwayDeltaR;
    int extR = railwayRadius + railwayDeltaR;
    drawCircle(imgRailway, railwayCenterX, railwayCenterY, extR, railwayPad, g.getColor());
    drawCircle(imgRailway, railwayCenterX, railwayCenterY, intR, railwayPad, g.getColor());
    drawRadii (imgRailway, railwayCenterX, railwayCenterY, intR, extR, tPad, g.getColor());
    drawStraightLine(imgRailway, railwayCenterX + railwayLength, railwayCenterY + intR, railwayCenterX, railwayCenterY + intR, railwayPad, g.getColor());
    drawStraightLine(imgRailway, railwayCenterX + railwayLength, railwayCenterY + extR, railwayCenterX, railwayCenterY + extR, railwayPad, g.getColor());
    drawVertT(imgRailway, railwayCenterX, railwayCenterX + railwayLength, railwayCenterY + intR, railwayCenterY + extR, tPad, g.getColor());
  }

  private static void createBridge() {
    int bridgeLength = 2 * (railwayDeltaR + railwayPad) + 10;
    int bridgeWidth = 4 * railwayDeltaR;
    int dx = 3 * railwayDeltaR / 2;
    int dy = 2 * dx;
    int top = railwayPad + dy;
    int left = railwayPad + dx;
    int right = left + bridgeWidth;
    int bottom = top + bridgeLength;
    imgBridge = new BufferedImage(right + left + 2, bottom + top + 1, BufferedImage.TYPE_INT_ARGB);
    Graphics2D g = imgBridge.createGraphics();
    g.setColor(bgrColor);
    g.fillRect(0, 0, pictureWidth, pictureHeight);
    g.setColor(Color.BLACK);
    drawStraightLine(imgBridge,  left-dx, top-dy,  left,       top,    railwayPad, g.getColor());
    drawStraightLine(imgBridge,  left,    top,     left,    bottom,    railwayPad, g.getColor());
    drawStraightLine(imgBridge,  left,    bottom,  left-dx, bottom+dy, railwayPad, g.getColor());
    drawStraightLine(imgBridge, right+dx, top-dy, right,       top,    railwayPad, g.getColor());
    drawStraightLine(imgBridge, right,    top,    right,    bottom,    railwayPad, g.getColor());
    drawStraightLine(imgBridge, right,    bottom, right+dx, bottom+dy, railwayPad, g.getColor());
  }

  private static void createImmobileImages() {
    createRailwayImage();
    createBridge();
  }

  private static int carriageWidth() { // �������� �� ����� ����� � �� ����������
    int w = 5 * railwayDeltaR;
    if (w % 2 == 0) w++;
    return w;
  }

  private static int carriageLength() { // ��������� �� ����� ����� � �� ����������
    return 2 * carriageWidth() + 1;
  }

  private static int carriageBorderWidth() { // ���������� �� ������� �� �������� � ����������
    return railwayPad;
  }

  private static void drawCarriageOrEngine(BufferedImage img, int centerX, int centerY, double directionX, double directionY, Color internalColor, Color borderColor, boolean isEngine) {
    // directionX ^ 2 + directionY ^ 2 must be equal to 1!
    int W2 = carriageWidth() / 2;
    int L2 = carriageLength() / 2;
    int W1 = -W2;
    int L1 = -L2;
    int bw = carriageBorderWidth();
    int x1, y1, x2, y2;
    for (int W = W1; W <= W2; W++) {
      x1 = (int) Math.round(centerX + directionY * W - directionX * L1);
      y1 = (int) Math.round(centerY + directionX * W + directionY * L1);
      x2 = (int) Math.round(centerX + directionY * W - directionX * L2);
      y2 = (int) Math.round(centerY + directionX * W + directionY * L2);
      drawStraightLine(img, x1, y1, x2, y2, bw, bgrColor);
      x1 = (int) Math.round(centerX + directionY * (W + 0.5) - directionX * L1);
      y1 = (int) Math.round(centerY + directionX * (W + 0.5) + directionY * L1);
      x2 = (int) Math.round(centerX + directionY * (W + 0.5) - directionX * L2);
      y2 = (int) Math.round(centerY + directionX * (W + 0.5) + directionY * L2);
      drawStraightLine(img, x1, y1, x2, y2, bw, bgrColor);
    }
    int x11 = (int) Math.round(centerX + directionY * W1 - directionX * L1);
    int y11 = (int) Math.round(centerY + directionX * W1 + directionY * L1);
    int x12 = (int) Math.round(centerX + directionY * W1 - directionX * L2);
    int y12 = (int) Math.round(centerY + directionX * W1 + directionY * L2);
    int x21 = (int) Math.round(centerX + directionY * W2 - directionX * L1);
    int y21 = (int) Math.round(centerY + directionX * W2 + directionY * L1);
    int x22 = (int) Math.round(centerX + directionY * W2 - directionX * L2);
    int y22 = (int) Math.round(centerY + directionX * W2 + directionY * L2);
    drawStraightLine(img, x11, y11, x21, y21, bw, borderColor);
    drawStraightLine(img, x22, y22, x12, y12, bw, borderColor);
    drawStraightLine(img, x11, y11, x12, y12, bw, borderColor);
    drawStraightLine(img, x21, y21, x22, y22, bw, borderColor);
    floodFill(img, centerX, centerY, bgrColor, internalColor);
    int r = 0;
    int pad = 2 * bw;
    double step = L2 / 2;
    int dx = (int) Math.round(directionX * step);
    int dy = (int) Math.round(directionY * step);
    if (isEngine) {
      drawCircle(img, centerX,      centerY,      r, pad, borderColor);
      drawCircle(img, centerX + dx, centerY - dy, r, pad, borderColor);
      drawCircle(img, centerX - dx, centerY + dy, r, pad, borderColor);
    }
  }

  private static void drawCarriageOrEngineOnCircularRailway(BufferedImage img, double alpha, Color internalColor, Color borderColor, boolean isEngine) {
    double cosAlpha = Math.cos(alpha);
    double sinAlpha = Math.sin(alpha);
    int x = (int) Math.round(railwayCenterX + (railwayRadius - 1) * cosAlpha);
    int y = (int) Math.round(railwayCenterY + (railwayRadius - 1) * sinAlpha);
    drawCarriageOrEngine(img, x, y, sinAlpha, cosAlpha, internalColor, borderColor, isEngine);
  }

  private static void drawBlueCarriageOnCircularRailway(BufferedImage img, Color borderColor, double alpha) {
    drawCarriageOrEngineOnCircularRailway(img, alpha, BLUE, borderColor, false);
    if (img instanceof BufferedImageTrain) {
      CarriageEnginePosition pos = ((BufferedImageTrain)img).train.blueCarriagePosition;
      pos.isOnStraightRailway = false;
      pos.alpha = alpha;
    }
  }

  private static void drawRedCarriageOnCircularRailway(BufferedImage img, Color borderColor, double alpha) {
    drawCarriageOrEngineOnCircularRailway(img, alpha, RED, borderColor, false);
    if (img instanceof BufferedImageTrain) {
      CarriageEnginePosition pos = ((BufferedImageTrain)img).train.redCarriagePosition;
      pos.isOnStraightRailway = false;
      pos.alpha = alpha;
    }
  }

  private static void drawEngineOnCircularRailway(BufferedImage img, Color borderColor, double alpha) {
    drawCarriageOrEngineOnCircularRailway(img, alpha, Color.YELLOW, borderColor, true);
    if (img instanceof BufferedImageTrain) {
      CarriageEnginePosition pos = ((BufferedImageTrain)img).train.enginePosition;
      pos.isOnStraightRailway = false;
      pos.alpha = alpha;
    }
  }

  private static void drawCarriageOrEngineOnStraightRailway(BufferedImage img, int offsetX, Color internalColor, Color borderColor, boolean isEngine) {
    int x = railwayCenterX + offsetX;
    int y = railwayCenterY + railwayRadius - 1;
    drawCarriageOrEngine(img, x, y, 1, 0, internalColor, borderColor, isEngine);
  }

  private static void drawBlueCarriageOnStraightRailway(BufferedImage img, Color borderColor, int offsetX) {
    drawCarriageOrEngineOnStraightRailway(img, offsetX, BLUE, borderColor, false);
    if (img instanceof BufferedImageTrain) {
      CarriageEnginePosition pos = ((BufferedImageTrain) img).train.blueCarriagePosition;
      pos.isOnStraightRailway = true;
      pos.offsetX = offsetX;
    }
  }

  private static void drawRedCarriageOnStraightRailway(BufferedImage img, Color borderColor, int offsetX) {
    drawCarriageOrEngineOnStraightRailway(img, offsetX, RED, borderColor, false);
    if (img instanceof BufferedImageTrain) {
      CarriageEnginePosition pos = ((BufferedImageTrain) img).train.redCarriagePosition;
      pos.isOnStraightRailway = true;
      pos.offsetX = offsetX;
    }
  }

  private static void drawEngineOnStraightRailway(BufferedImage img, Color borderColor, int offsetX) {
    drawCarriageOrEngineOnStraightRailway(img, offsetX, YELLOW, borderColor, true);
    if (img instanceof BufferedImageTrain) {
      CarriageEnginePosition pos = ((BufferedImageTrain) img).train.enginePosition;
      pos.isOnStraightRailway = true;
      pos.offsetX = offsetX;
    }
  }

  private static void drawConfOfSouthRailway(BufferedImage img, Color borderColor, String conf) {
    int L = carriageLength();
    int offsetX = railwayLength - 20 - L/2;
    for(int k = 0; k < conf.length(); k++) {
      switch (conf.charAt(k)) {
        case 'B': drawBlueCarriageOnStraightRailway(img, borderColor, offsetX); break;
        case 'R':  drawRedCarriageOnStraightRailway(img, borderColor, offsetX); break;
        case 'E':       drawEngineOnStraightRailway(img, borderColor, offsetX); break;
      }
      offsetX -= L;
    }
  }

  private static void drawConfOfCircularRailway(BufferedImage img, Color borderColor, String conf, boolean isEast) {
    double distAlpha = 2 * Math.atan(carriageLength()/2.0/(railwayRadius-1-carriageWidth()/2)); // ����� ������ �� �������� � ����������
    if (!isEast) 
      distAlpha = -distAlpha;
    double alpha = (isEast) ? 0 : Math.PI;
    if (conf.length() > 1)
      if (conf.charAt(0) == 'E')
        alpha = alpha - distAlpha;
    for (int k = 0; k < conf.length(); k++) {
      switch (conf.charAt(k)) {
        case 'B': drawBlueCarriageOnCircularRailway(img, borderColor, alpha); break;
        case 'R':  drawRedCarriageOnCircularRailway(img, borderColor, alpha); break;
        case 'E':       drawEngineOnCircularRailway(img, borderColor, alpha); break;
      }
      alpha += distAlpha;
    }
  }

  private static void drawConfOfEastRailway(BufferedImage img, Color borderColor, String conf) {
    drawConfOfCircularRailway(img, borderColor, conf, true);
  }

  private static void drawConfOfWestRailway(BufferedImage img, Color borderColor, String conf) {
    drawConfOfCircularRailway(img, borderColor, conf, false);
  }

  private static void drawMobileImages(BufferedImage img, Color borderColor, TrainConfiguration conf) {
     drawConfOfEastRailway(img, borderColor, conf.east );
     drawConfOfWestRailway(img, borderColor, conf.west );
    drawConfOfSouthRailway(img, borderColor, conf.south);
  }

  private static void drawBlueCarriagePosition(BufferedImage img, Color borderColor, CarriageEnginePosition pos) {
    if (pos.isOnStraightRailway)
      drawBlueCarriageOnStraightRailway(img, borderColor, pos.offsetX);
    else
      drawBlueCarriageOnCircularRailway(img, borderColor, pos.alpha);
  }

  private static void drawRedCarriagePosition(BufferedImage img, Color borderColor, CarriageEnginePosition pos) {
    if (pos.isOnStraightRailway)
      drawRedCarriageOnStraightRailway(img, borderColor, pos.offsetX);
    else
      drawRedCarriageOnCircularRailway(img, borderColor, pos.alpha);
  }

  private static void drawEnginePosition(BufferedImage img, Color borderColor, CarriageEnginePosition pos) {
    if (pos.isOnStraightRailway)
      drawEngineOnStraightRailway(img, borderColor, pos.offsetX);
    else
      drawEngineOnCircularRailway(img, borderColor, pos.alpha);
  }

  private static void drawTrainPositions(BufferedImage img, Color borderColor, TrainPositions train) {
    drawBlueCarriagePosition(img, borderColor, train.blueCarriagePosition);
     drawRedCarriagePosition(img, borderColor, train. redCarriagePosition);
          drawEnginePosition(img, borderColor, train.      enginePosition);
  }

  private static void mixPositions(CarriageEnginePosition pos1, CarriageEnginePosition pos2, double t, CarriageEnginePosition mixed, boolean clockwise) {
    // mixed = t * pos2 + (1-t) * pos1
    if (pos1.equals(pos2)) {
      mixed.assign(pos1);
      return;
    }
    if (pos1.isOnStraightRailway) {
      if (pos2.isOnStraightRailway) {
        mixed.isOnStraightRailway = true;
        mixed.offsetX = (int) Math.round(t * pos2.offsetX + (1-t) * pos1.offsetX);
      }
      else {
        int offsetX = pos1.offsetX;
        double alpha = standardAngle(pos2.alpha);
        if (alpha < Math.PI / 2)   // Math.PI / 2 = �� ���������
          alpha += 2 * Math.PI;
        double tBranch = offsetX / (offsetX + (railwayRadius - 1) * (alpha - Math.PI / 2));
        if (t <= tBranch) {
          mixed.isOnStraightRailway = true;
          mixed.offsetX = (int) Math.round((1 - t / tBranch) * offsetX);
        }
        else {
          mixed.isOnStraightRailway = false;
          mixed.alpha = ((t - tBranch) * alpha + (1 - t) * Math.PI / 2) / (1 - tBranch);
        }
      }
    }
    else {
      if (pos2.isOnStraightRailway) {
        mixPositions(pos2, pos1, 1-t, mixed, clockwise);
      }
      else {
        mixed.isOnStraightRailway = false;
        double alpha1 = standardAngle(pos1.alpha);
        double alpha2 = standardAngle(pos2.alpha);
        if (clockwise) {
          if (alpha2 < alpha1)
            alpha2 += 2 * Math.PI;
        }
        else {
          if (alpha2 > alpha1)
            alpha2 -= 2 * Math.PI;
        }
        mixed.alpha = t * alpha2 + (1-t) * alpha1;
      }
    }
  }

  private static TrainPositions mixTrainPositions(TrainPositions train1, TrainPositions train2, double t, boolean clockwise) {
    // result = t * train2 + (1-t) * train1
    TrainPositions mixed = new TrainPositions();
    mixPositions(train1.blueCarriagePosition, train2.blueCarriagePosition, t, mixed.blueCarriagePosition, clockwise);
    mixPositions(train1. redCarriagePosition, train2. redCarriagePosition, t, mixed. redCarriagePosition, clockwise);
    mixPositions(train1.      enginePosition, train2.      enginePosition, t, mixed.      enginePosition, clockwise);
    return mixed;
  }

  private static void drawMobileImages(BufferedImage imgMixed, Color clr, TrainPositions train1, TrainPositions train2, double t, boolean clockwise) {
    TrainPositions trainMixed = mixTrainPositions(train1, train2, t, clockwise);
    drawTrainPositions(imgMixed, clr, trainMixed);
  }

  private static BufferedImageTrain createScene(TrainConfiguration conf, TrainPositions train1, TrainPositions train2, double t, boolean clockwise) {
    // If conf == null, then mix two scenes, else create a scene from conf (ignore the remaining parameters).
    BufferedImageTrain imgScene = new BufferedImageTrain(imgRailway.getWidth(), imgRailway.getHeight(), BufferedImage.TYPE_INT_ARGB);
    Graphics2D g = imgScene.createGraphics();
    g.setColor(Color.BLACK);
    g.drawImage(imgRailway, 0, 0, null);
    if (conf == null)
      drawMobileImages(imgScene, g.getColor(), train1, train2, t, clockwise);
    else
      drawMobileImages(imgScene, g.getColor(), conf);
    g.drawImage(imgBridge, railwayCenterX - imgBridge.getWidth()/2, railwayCenterY - railwayRadius - imgBridge.getHeight()/2, null);
    return imgScene;
  }

  private static BufferedImageTrain createScene(TrainConfiguration conf) {
    return createScene(conf, null, null, 0.0, false);
  }

  private static BufferedImageTrain createScene(TrainPositions train1, TrainPositions train2, double t, boolean clockwise) {
    // This method mixes train1 and train2, i.e. it returns t * train2 + (1-t) * train1
    return createScene(null, train1, train2, t, clockwise);
  }

  private static void writeImageToFile(BufferedImage img, String imageName) throws IOException {
    final String imageFormat = "png";
    javax.imageio.ImageIO.write(img, imageFormat, new File(imageName + "." + imageFormat));
  }

  // ��������

  // �������� �� ���������� �� �� ���� XYn, ������:
  // X � �������� ������� �� ���������� (S = south, E = east, W = west);
  // Y � ������ ������� �� ���������� (S, E, W);
  // n � ����� �� ��������, ����� ����������� ����� (0, 1, 2);
  // �� �� ����� ��������, ����� ����������� ����.
  // ���������� ��, �� ����������� �� ������ ��� �����,
  // ������ ����� ������ �� �������� � �������� ������� ��� �������
  // (���� ��� �� ���� ������).
  // ������ ���� ������ n ���� �� ���� ������� B = bridge:
  // ������ ����������� ������ ��� �����.

  private static final int MVM_SW0 =  1;
  private static final int MVM_SW1 =  2;
  private static final int MVM_SW2 =  3;
  private static final int MVM_WS0 =  4;
  private static final int MVM_WS1 =  5;
  private static final int MVM_WS2 =  6;
  private static final int MVM_EW0 =  7;
  private static final int MVM_EW1 =  8;
  private static final int MVM_EW2 =  9;
  private static final int MVM_WE0 = 10;
  private static final int MVM_WE1 = 11;
  private static final int MVM_WE2 = 12;
  private static final int MVM_EWB = 13;
  private static final int MVM_WEB = 14;

  private static String reverseString(String s) {
    if (s == null)
      return null;
    String result = "";
    while (s.length() > 0) {
      result = s.substring(0, 1) + result;
      s = s.substring(1);
    }
    return result;
  }

  private static double standardAngle(double alpha) {
    // result = alpha % (2 * pi)
    int k = (int) Math.round(Math.floor(alpha / (2 * Math.PI)));
    return alpha - 2 * k * Math.PI;
  }

  private static TrainConfigurationsWithMovements getMoves(TrainConfiguration confCurrent) {
    if (confCurrent == null)
      return null;
    int n;
    TrainConfiguration confNew = null;
    TrainConfigurationsWithMovements result = new TrainConfigurationsWithMovements();
    n = confCurrent.east.indexOf('E');
    if (n >= 0) { // ����������� � � �������� ������� �� �� �������
      if (n == 0) {
        result.movements = new int[2];
        result.confs = new TrainConfiguration[3];
        result.movements[1] = MVM_EWB;
        confNew = new TrainConfiguration(confCurrent);
        confNew.east = confNew.east.substring(1);
        confNew.west = "E" + confNew.west;
        result.confs[2] = confNew;
      }
      else {
        result.movements = new int[n+1];
        result.confs = new TrainConfiguration[n+2];
      }
      for (int k = 0; k <= n; k++) {
        result.movements[k] = MVM_EW0 + k;
        confNew = new TrainConfiguration(confCurrent);
        confNew.west = confNew.west + reverseString(confNew.east.substring(n-k));
        confNew.east = confNew.east.substring(0, n-k);
        result.confs[k+1] = confNew;
      }
    }
    n = confCurrent.west.indexOf('E');
    if (n >= 0) { // ����������� � � �������� ������� �� �� �������
      if (n == 0) {
        result.movements = new int[3];
        result.confs = new TrainConfiguration[4];
        result.movements[2] = MVM_WEB;
        confNew = new TrainConfiguration(confCurrent);
        confNew.west = confNew.west.substring(1);
        confNew.east = "E" + confNew.east;
        result.confs[3] = confNew;
      }
      else {
        result.movements = new int[2*n+2];
        result.confs = new TrainConfiguration[2*n+3];
      }
      for (int k = 0; k <= n; k++) {
        result.movements[k] = MVM_WE0 + k;
        confNew = new TrainConfiguration(confCurrent);
        confNew.east = confNew.east + reverseString(confNew.west.substring(n-k));
        confNew.west = confNew.west.substring(0, n-k);
        result.confs[k+1] = confNew;
      }
      for (int k = 0; k <= n; k++) {
        result.movements[n+k+1] = MVM_WS0 + k;
        confNew = new TrainConfiguration(confCurrent);
        confNew.south = confNew.south + reverseString(confNew.west.substring(n-k));
        confNew.west = confNew.west.substring(0, n-k);
        result.confs[n+k+2] = confNew;
      }
    }
    n = confCurrent.south.indexOf('E');
    if (n >= 0) { // ����������� � � ����� ������� �� �� �������
      result.movements = new int[n+1];
      result.confs = new TrainConfiguration[n+2];
      for (int k = 0; k <= n; k++) {
        result.movements[k] = MVM_SW0 + k;
        confNew = new TrainConfiguration(confCurrent);
        confNew.west = confNew.west + reverseString(confNew.south.substring(n-k));
        confNew.south = confNew.south.substring(0, n-k);
        result.confs[k+1] = confNew;
      }
    }
    result.confs[0] = confCurrent;
    return result;
  }

  private static TrainConfigurationsWithMovements searchBFS(TrainConfiguration confInitial, TrainConfiguration confFinal) {
    final int CONF_COUNT = 60;
    TrainConfiguration[] confs = new TrainConfiguration[CONF_COUNT];
    int[] movements = new int[CONF_COUNT];
    int[] parents = new int[CONF_COUNT];
    int[] depths = new int[CONF_COUNT];
    int head = 0;
    int tail = 0;
    confs[0] = confInitial;
    movements[0] = -1;
    parents[0] = -1;
    depths[0] = 0;
    while (head <= tail) {
      TrainConfiguration confCurrent = confs[head];
      if (confCurrent.equals(confFinal)) {
        TrainConfigurationsWithMovements report = new TrainConfigurationsWithMovements();
        report.confs = new TrainConfiguration[depths[head]+1];
        report.movements = (depths[head] == 0) ? null : new int[depths[head]];
        report.confs[depths[head]] = confCurrent;
        while (depths[head] > 0) {
          report.movements[depths[head]-1] = movements[head];
          head = parents[head];
          confCurrent = confs[head];
          report.confs[depths[head]] = confCurrent;
        }
        return report;
      }
      TrainConfigurationsWithMovements moves = getMoves(confCurrent);
      for (int k = 1; k < moves.confs.length; k++) {
        confCurrent = moves.confs[k];
        boolean found = false;
        for (int j = 0; j <= tail; j++) {
          if (confCurrent.equals(confs[j])) {
            found = true;
            break;
          }
        }
        if (!found) {
          tail++;
          confs[tail] = confCurrent;
          movements[tail] = moves.movements[k-1];
          parents[tail] = head;
          depths[tail] = depths[head]+1;
        }
      }
      head++;
    }
    return null;
  }

  private static String numToStr8(int n) {
    String s = "" + n;
    while (s.length() < 8) s = "0" + s;
    return s;
  }

  private static void playSolution(TrainConfigurationsWithMovements solution, String fileNameWithoutExtension) throws IOException, InterruptedException {
    if (solution == null)
      return;
    if (solution.confs == null)
      return;
    if (solution.confs.length <= 0)
      return;
    createImmobileImages();
    int numScene = 0;
    TrainConfiguration conf = solution.confs[0];
    BufferedImageTrain img = createScene(conf);
    TrainPositions trainOld = img.train;
    writeImageToFile(img, numToStr8(numScene));
    numScene++;
    for (int k = 1; k < solution.confs.length; k++) {
      conf = solution.confs[k];
      int move = solution.movements[k-1];
      boolean clockwise = (move == MVM_EW0 || move == MVM_EW1 || move == MVM_EW2 || move == MVM_WEB);
      img = createScene(conf);
      TrainPositions trainNew = img.train;
      final double step = 0.01;
      for (double t = step; t < 1.000; t += step) {
        BufferedImage imgTransient = createScene(trainOld, trainNew, t, clockwise);
        writeImageToFile(imgTransient, numToStr8(numScene));
        numScene++;
        Thread.sleep(1000);
      }
      writeImageToFile(img, numToStr8(numScene));
      numScene++;
      trainOld = trainNew;
    }
  }

  // ������, ��������� �� main():

  private static void printHelp() {
    System.out.println();
    System.out.println("   This program solves the 'Low Bridge' puzzle.");
    System.out.println("Two syntaxes are possible:");
    System.out.println("1) single_configuration;");
    System.out.println("2) initial_configuration final_configuration.");
    System.out.println("Replace the parameters with appropriate values.");
    System.out.println("   Configurations are specified as five-character strings:");
    System.out.println("one E (engine), one R (red carriage), one B (blue carriage),");
    System.out.println("and two underscores. The underscores are delimiters:");
    System.out.println("they split the string to three parts: east, west, south.");
    System.out.println("The east and west portions are described north-to-south,");
    System.out.println("whereas the south portion is described east-to-west.");
    System.out.println("   The first syntax prints a single configuration to a PNG file");
    System.out.println("in the current folder. The file is named after the configuration.");
    System.out.println("   The second syntax transforms one configuration to another");
    System.out.println("and prints the stages to multiple PNG files in the current folder.");
    System.out.println("The file names are consecutive numbers so that the files can easily");
    System.out.println("be converted to an animation (another program is necessary).");
    System.out.println("The program also prints the solution to the standard output:");
    System.out.println("it contains the sequence of configurations, one at a line.");
  }

  private static void printConfiguration(String s) throws IOException {
    TrainConfiguration conf = new TrainConfiguration(s);
    createImmobileImages();
    BufferedImage img = createScene(conf);
    writeImageToFile(img, s);
  }

  private static void searchForPath(String sInitial, String sFinal) throws IOException, InterruptedException {
    TrainConfiguration confInitial = new TrainConfiguration(sInitial);
    TrainConfiguration confFinal   = new TrainConfiguration(sFinal);
    TrainConfigurationsWithMovements report = searchBFS(confInitial, confFinal);
    System.out.println();
    System.out.println("Initial configuration: " + sInitial + ".");
    System.out.println("  Final configuration: " + sFinal   + ".");
    System.out.println();
    if (report == null)
      System.out.println("No solution.");
    else {
      System.out.println("Solution:");
      System.out.println();
      for (int k = 0; k < report.confs.length; k++)
        System.out.println(report.confs[k].toString());
      playSolution(report, sInitial + "---" + sFinal);
    }
  }

  public static void main(String[] args) {
     try {
      switch (args.length) {
        case 0: printHelp(); break;
        case 1: printConfiguration(args[0]); break;
        case 2: searchForPath(args[0], args[1]); break;
        default: throw new IOException("Too many parameters.");
      }
    }
    catch(Throwable x) {
      System.err.println();
      System.err.println(x.getMessage());
    }
  }
}