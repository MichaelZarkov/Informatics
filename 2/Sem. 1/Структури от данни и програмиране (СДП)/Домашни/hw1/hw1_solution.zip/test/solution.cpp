#include "catch2/catch_all.hpp"
#include "solution.h"

TEST_CASE("isCorrect() recognizes correct expressions")
{
	SECTION("Empty expression") {
		REQUIRE(isCorrect(""));
	}
	SECTION("No brackets") {
		REQUIRE(isCorrect("abc"));
	}
	SECTION("One pair of brackets") {
		REQUIRE(isCorrect("(abc)"));
	}
	SECTION("Multiple brackets") {
		REQUIRE(isCorrect("(((abc)))"));
	}
	SECTION("Mixed brackets") {
		REQUIRE(isCorrect("([abc])"));
	}
	SECTION("Complex expression") {
		REQUIRE(isCorrect("((abc) { abc }(((def)))def)"));
	}
	SECTION("Single pair of brackets") {
		REQUIRE(isCorrect("()"));
	}
	SECTION("Brackets-only") {
		REQUIRE(isCorrect("((()))"));
	}
	SECTION("Brackets next to each other") {
		REQUIRE(isCorrect("{}[](){}[]()"));
	}
}

TEST_CASE("isCorrect() recognizes when an expression is incorrect")
{
	SECTION("Wrong order brackets") {
		REQUIRE_FALSE(isCorrect(")("));    // New requirement
	}
	SECTION("No closing bracket") {
		REQUIRE_FALSE(isCorrect("(abc"));
	}
	SECTION("No closing bracket and multiple brackets") {
		REQUIRE_FALSE(isCorrect("(((abc))"));
	}
	SECTION("No opening bracket") {
		REQUIRE_FALSE(isCorrect("abc)"));
	}
	SECTION("No opening bracket and mutliple brackets") {
		REQUIRE_FALSE(isCorrect("(abc))"));
	}
	SECTION("Single opening bracket") {
		REQUIRE_FALSE(isCorrect("("));
	}
	SECTION("Single closing bracket") {
		REQUIRE_FALSE(isCorrect(")"));
	}
	SECTION("Bracket types do not match") {
		REQUIRE_FALSE(isCorrect("{abc]"));
	}
	SECTION("Overlapping bracket sub-expressions") {
		REQUIRE_FALSE(isCorrect("(abcdef[)]"));
	}
}


// Tests for the bracket recognizing functions:

TEST_CASE("isBracket() recognizes brackets correctly") {

	SECTION("(") {
		REQUIRE(isBracket('('));
	}
	SECTION(")") {
		REQUIRE(isBracket(')'));
	}
	SECTION("[") {
		REQUIRE(isBracket('['));
	}
	SECTION("]") {
		REQUIRE(isBracket(']'));
	}
	SECTION("{") {
		REQUIRE(isBracket('{'));
	}
	SECTION("}") {
		REQUIRE(isBracket('}'));
	}
}
TEST_CASE("isBracket() recognizes non-brackets") {
	
	SECTION("char forn 0 to (") {
		for (char i = 0; i < '('; ++i) {
			REQUIRE_FALSE(isBracket(i));
		}
	}
	SECTION("char forn ) to [") {
		for (char i = ')' + 1; i < '['; ++i) {
			REQUIRE_FALSE(isBracket(i));
		}
	}
	SECTION("char forn ] to {") {
		for (char i = ']' + 1; i < '{'; ++i) {
			REQUIRE_FALSE(isBracket(i));
		}
	}
}

TEST_CASE("isOppositeBrackets() recognises (), [], {}") {

	SECTION("recognize ()") {
		REQUIRE(isOppositeBrackets('(', ')'));
	}
	SECTION("recognize []") {
		REQUIRE(isOppositeBrackets('[', ']'));
	}
	SECTION("recognize {}") {
		REQUIRE(isOppositeBrackets('{', '}'));
	}
}
TEST_CASE("isOppositeBrackets() doesnot recognize anything else") {
	
	int char_max_val = 128;
	SECTION("first char == )") {
		for (int i = 0; i < char_max_val; ++i) {
			REQUIRE_FALSE(isOppositeBrackets(')', i));
		}
	}
	SECTION("first char == ]") {
		for (int i = 0; i < char_max_val; ++i) {
			REQUIRE_FALSE(isOppositeBrackets(']', i));
		}
	}
	SECTION("first char == }") {
		for (int i = 0; i < char_max_val; ++i) {
			REQUIRE_FALSE(isOppositeBrackets('}', i));
		}
	}
}