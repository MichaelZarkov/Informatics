#pragma once

bool isCorrect(const char* expression);

bool isBracket(char);
bool isOppositeBrackets(char c1, char c2);