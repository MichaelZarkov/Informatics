
#include <stack>
#include "solution.h"

bool isBracket(char c)
{
	return c == '(' || c == '[' || c == '{' || c == ')' || c == ']' || c == '}';
}

bool isOppositeNormalBrackets(char c1, char c2)
{
	return c1 == '(' && c2 == ')';
}

bool isOppositeSquareBrackets(char c1, char c2)
{
	return c1 == '[' && c2 == ']';
}

bool isOppositeCurlyBrackets(char c1, char c2)
{
	return c1 == '{' && c2 == '}';
}

// Returns true if c1 == (, c2 == )
//                 c1 == [, c2 == ]
//                 c1 == {, c2 == }
bool isOppositeBrackets(char c1, char c2)
{
	return isOppositeNormalBrackets(c1, c2) ||
		   isOppositeSquareBrackets(c1, c2) ||
		   isOppositeCurlyBrackets(c1, c2);
}

// - Pushes only brackets to the stack "( ) [ ] { }".
// 
// - If the top element in the stack is opening bracket and *expression
//   is the matching closing bracket, then pop() (they "cancel" each other).
//   EX: top == (, *expression == ), then pop().
// 
// - In a correct expression all brackets "cancel" each other out and no
//   brackets will be left in the stack (return true).
// 
// - In an incorrect expression some brackets will be left "uncanceled"
//   so stack will not be empty (return false).
bool isCorrect(const char* expression)
{
	std::stack<char> brackets;

	while (*expression) {
		if (isBracket(*expression)) {
			if (!brackets.empty() && isOppositeBrackets(brackets.top(), *expression)) {
				brackets.pop();
			}
			else {
				brackets.push(*expression);
			}
		}
		++expression;
	}

	return brackets.empty();    // If the stack is empty then "expression" is correct.
}