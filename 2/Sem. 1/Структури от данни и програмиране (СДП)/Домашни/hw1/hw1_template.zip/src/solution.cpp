#include "solution.h"

bool isCorrect(const char* expression)
{
  return false;
}