﻿#pragma once 

#include <vector>
#include <stack>
#include <queue>

#include "Node.h"


//WEIGHT BALANCE CHECK
template<typename t>
bool isBalanced(const Node<t>* rootptr)
{
    if (rootptr == nullptr) return true;

    int leftWeight = 0;
    int rightWeight = 0;

    leftWeight = getWeight(rootptr->left);
    rightWeight = getWeight(rootptr->right);

    return std::abs(leftWeight - rightWeight) <= 1 &&
        isBalanced(rootptr->left) && isBalanced(rootptr->right);
}

//HEIGHT BALANCE CHECK
//template<typename T>
//bool isBalanced(const Node<T>* rootptr)
//{
//    int leftHeight;
//
//    int rightHeight;
//
//    if (rootptr == nullptr)
//        return 1;
//
//    leftHeight = getHeight(rootptr->left);
//    rightHeight = getHeight(rootptr->right);
//
//    if (abs(leftHeight - rightHeight) <= 1 && isBalanced(rootptr->left) && isBalanced(rootptr->right))
//        return 1;
//
//    return 0;
//
//    //Условието в доманото и дефиницията в уикипедия са различни и теста на 98 ред прави проблем а не трябва (aka it's bullsh*t)
//}


//template<typename T>
//bool isBst(const Node<T>* rootptr)
//{
//    if (rootptr == nullptr) return true;
//    //if(!isBalanced(rootptr)) return false;
//
//    if (rootptr->hasLeftSuccessor() &&
//        (rootptr->left->data > rootptr->data))
//        return false;
//
//    if (rootptr->hasRightSuccessor() &&
//        (rootptr->right->data < rootptr->data))
//        return false;
//
//    return isBst(rootptr->left) && isBst(rootptr->right);
//}

//DONE I guess
template<typename T>
int maxValue(Node<T>* rootptr)
{
    if (rootptr == nullptr) {
        return INT16_MIN;
    }
    int value = rootptr->data;
    int leftMax = maxValue(rootptr->left);
    int rightMax = maxValue(rootptr->right);

    return std::max(value, std::max(leftMax, rightMax));
}
template<typename T>
int minValue(Node<T>* rootptr)
{
    if (rootptr == nullptr) {
        return INT16_MAX;
    }
    int value = rootptr->data;
    int leftMax = minValue(rootptr->left);
    int rightMax = minValue(rootptr->right);

    return std::min(value, std::min(leftMax, rightMax));
}
template<typename T>
bool isBst(const Node<T>* rootptr)
{
    if (rootptr == nullptr)
        return 1;

    /* false if the max of the left is > than us */
    if (rootptr->left != nullptr && maxValue(rootptr->left) > rootptr->data)
        return 0;

    /* false if the min of the right is <= than us */
    if (rootptr->right != nullptr && minValue(rootptr->right) < rootptr->data)
        return 0;

    /* false if, recursively, the left or right is not a BST */
    if (!isBst(rootptr->left) || !isBst(rootptr->right))
        return 0;

    /* passing all that, it's a BST */
    return 1;
}

template<typename T>
void release(Node<T>* rootptr)
{
    if (rootptr == nullptr) return;

    release(rootptr->left);
    release(rootptr->right);

    delete rootptr;
}

template<typename T>
Node<T>* toBalanced(std::vector<T> data)
{
    if (data.empty()) return nullptr;

    int n = data.size();
    Node<T>* root = new Node<T>(data[n / 2]);

    std::vector<T> left(data.begin(), data.begin() + (n / 2));
    std::vector<T> right(data.begin() + (n / 2) + 1, data.end());

    root->left = toBalanced(left);
    root->right = toBalanced(right);
    return root;
}

template<typename T>
std::vector<T> toVector(const Node<T>* rootptr)
{
    std::vector<T> result;
    if (rootptr == nullptr) return result;

    std::vector<T> left = toVector(rootptr->left);
    result.insert(result.end(), left.begin(), left.end());

    result.push_back(rootptr->data);

    std::vector<T> right = toVector(rootptr->right);
    result.insert(result.end(), right.begin(), right.end());

    return result;
}

template<typename T>
std::vector<T> level(const Node<T>* rootptr, int level)
{
    std::vector<T> result;
    if (rootptr == nullptr || getHeight(rootptr) < level + 1) return result;

    std::queue<const Node<T>*> queue;
    queue.push(rootptr);
    int currLevel = 0;

    while (!queue.empty())
    {
        int size = queue.size();
        for (int i = 0; i < size; i++)
        {
            Node<T>* curr = (Node<T>*)queue.front();
            queue.pop();

            if (currLevel == level)
            {
                result.push_back(curr->data);
            }
            else
            {
                if (curr->left)
                {
                    queue.push(curr->left);
                }
                if (curr->right)
                {
                    queue.push(curr->right);
                }
            }
        }
        currLevel++;
    }
    return result;
}

// Help functions
template<typename T>
int getHeight(const Node<T>* rootptr)
{
    if (rootptr == nullptr)
        return 0;

    int leftHeight = getHeight(rootptr->left);
    int rightHeight = getHeight(rootptr->right);
    return std::max(leftHeight, rightHeight) + 1;
}

template<typename T>
int getWeight(const Node<T>* root) {
    if (root == nullptr) return 0;
    return getWeight(root->left) + getWeight(root->right) + 1;
}

