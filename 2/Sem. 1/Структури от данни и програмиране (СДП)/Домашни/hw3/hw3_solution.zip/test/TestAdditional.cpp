#include "catch2/catch_all.hpp"
#include "Solution.h"

//TODO Add your own unit tests here (if you need any)