#pragma once 

#include <cstdlib>    // abs()
#include <new>        // std::nothrow, std::bad_alloc

#include <vector>
#include <stack>

#include "Node.h"


// Returns -1 if the tree is not weight-balanced.
// Returns the weight of the tree if it is weight-balance.
template<typename T>
int isBalancedRec(const Node<T>* root)
{
	if (root == nullptr)
		return 0;

	int leftWeight = isBalancedRec(root->left);
	if (leftWeight == -1)
		return -1;

	int rightWeight = isBalancedRec(root->right);
	if (rightWeight == -1)
		return -1;

	if (abs(leftWeight - rightWeight) > 1)
	{
		return -1;     // The whole tree is not weight-balanced.
	}
	else
	{
		return leftWeight + rightWeight + 1;   // This subtree is balanced.
	}
}
template<typename T>
bool isBalanced(const Node<T>* rootptr)
{
	return isBalancedRec(rootptr) != -1;
}

// Returns true if the tree is BST.
//
// 'min' - minimum value allowed for 'data' inclusive ('min <= data').
// 'max' - maximun value allowed for 'data' not inclusive ('data < max').
//
// 'min == nullptr' represents negative infinity (or lowest possible value).
// 'max == nullptr' represents positive infinity (highest possible value).
//
// The function works by narrowing down the lower and upper bounds (min, max) for every
// recursive call. If an element in the tree isn't in the required bounds, then the tree 
// is not BST.
template<typename T>
bool isBstRec(const Node<T>* root, const T* min, const T* max)
{
	if (root == nullptr)
		return true;

	// The ternary operators deal with when 'min' and 'max' are nullptr.
	return (min ? *min <= root->data : true) && (max ? root->data < *max : true) &&     // Check if 'data' is in bounds.
		isBstRec(root->left, min, &root->data) &&                                       // Check if left subtree is BST.
		isBstRec(root->right, &root->data, max);                                        // Check if right subtree is BST.
}
template<typename T>
bool isBst(const Node<T>* rootptr)
{
	return isBstRec(rootptr, (T*)nullptr, (T*)nullptr);
}

template<typename T>
void release(Node<T>* rootptr)
{
	if (rootptr == nullptr)
		return;
	
	release(rootptr->left);
	release(rootptr->right);

	delete rootptr;
}

template<typename T>
Node<T>* toBalancedRec(const std::vector<T>& data, size_t first, size_t last)
{
	if (first == last)
		return nullptr;

	// Save the middle element of the array in new node (array is from 'first' to 'last - 1').
	// 'last' is the position after the last element of the array.
	size_t middleElement = first + (last - first) / 2;
	Node<T>* newNode = new Node<T>{ data[middleElement] };

	// Call recursively for the left and right subarrays.
	newNode->left = toBalancedRec(data, first, middleElement);
	newNode->right = toBalancedRec(data, middleElement + 1, last);

	return newNode;
}
template<typename T>
Node<T>* toBalanced(std::vector<T> data)   // Why isn't 'data' const reference ???
{
	if (data.size() == 0)
		return nullptr;

	// This code for the root node is not in the recursive function because if
	// mem alloc fails I need the root node to delete the whole tree.
	size_t middleElement = data.size() / 2;
	Node<T>* root = new Node<T>{ data[middleElement] };

	try
	{
		root->left = toBalancedRec(data, 0, middleElement);
		root->right = toBalancedRec(data, middleElement + 1, data.size());
	}
	catch (...)
	{
		release(root);
		throw std::bad_alloc();
	}

	return root;
}

template<typename T>
void toVectorRec(std::vector<T>& array, const Node<T>* root)
{
	if (root == nullptr)
		return;

	toVectorRec(array, root->left);
	array.push_back(root->data);
	toVectorRec(array, root->right);
}
template<typename T>
std::vector<T> toVector(const Node<T>* rootptr)
{
	std::vector<T> array;
	toVectorRec(array, rootptr);
	return array;        // No 'std::move()' here because the compiler is smart enough.
}

template<typename T>
void levelRec(std::vector<T>& elementsAtLevel, const Node<T>* root, int& level)
{
	if (root == nullptr)
		return;

	if (level)
	{
		// Not at the right level. Go down.
		--level;
		levelRec(elementsAtLevel, root->left, level);
		levelRec(elementsAtLevel, root->right, level);
		++level;
	}
	else
	{
		// Reached the right level. Save the element.
		elementsAtLevel.push_back(root->data);
	}
}
template<typename T>
std::vector<T> level(const Node<T>* rootptr, int level)
{
	std::vector<T> elementsAtLevel;
	levelRec(elementsAtLevel, rootptr, level);
	return elementsAtLevel;        // No 'std::move()' here because the compiler is smart enough.
}
