// Author: Michael Zarkov

#include "solution.h"

#include <new>
#include <stdexcept>

void removeConsecutiveDuplicates(Node* first)
{
	if (!first)
		return;

	Node* compareTo = first;
	Node* currNode = first->next;
	while (currNode)
	{
		if (currNode->value == compareTo->value)
		{
			compareTo->next = currNode->next;
			delete currNode;
			currNode = compareTo->next;
		}
		else
		{
			compareTo = currNode;
			currNode = currNode->next;
		}
	}
}

Node* reverseList(Node* head)
{
	if (!head)
		return nullptr;

	Node* prevNode = head;
	Node* currNode = head->next;
	prevNode->next = nullptr;
	while (currNode)
	{
		Node* nextNode = currNode->next;
		currNode->next = prevNode;
		prevNode = currNode;
		currNode = nextNode;
	}

	return prevNode;
}

void deleteList(Node* head)
{
	if (head)
	{
		deleteList(head->next);
		delete head;
	}
}

Node* cloneList(Node* head)
{
	if (!head)
		return nullptr;

	Node* newHead = new Node{ head->value, nullptr };
	head = head->next;

	Node* currNode = newHead;
	while (head)
	{
		currNode->next = new(std::nothrow) Node{ head->value, nullptr };
		if (!currNode)
		{
			deleteList(newHead);
			std::bad_alloc ba;
			throw ba;
		}

		currNode = currNode->next;
		head = head->next;
	}

	return newHead;
}

size_t findListLength(Node* head)
{
	size_t count = 0;
	while (head)
	{
		head = head->next;
		++count;
	}
	return count;
}

Node* cloneReversed(Node* first)
{
	if (!first)
		return nullptr;

	// Solution 2.
	// Alloc all nodes at once in an array.
	size_t size = findListLength(first);
	
	Node* newHead = new Node[size];   // Allocate all nodes at once.

	// Copy values from list 'first' in reverse order.
	Node* copyFrom = first;
	size_t i = size - 1;
	while (copyFrom)
	{
		newHead[i].value = copyFrom->value;
		newHead[i].next = &newHead[i + 1];    // Current node is pointing to the next node in the array.

		copyFrom = copyFrom->next;
		--i;
	}
	newHead[size - 1].next = nullptr;   // Last node is not pointing to anything.

	return newHead;
	
	//// Solution 1.
	//// Alloc nodes one by one.
	//return reverseList(cloneList(first));
}