#pragma once

#include "Allocator.h"
#include "Node.h"

#include <stdexcept>
#include <algorithm>

bool isHeightBalanced(Node<int>* rootptr)
{
    throw std::exception();
}

template <typename AllocatorType>
void free(Node<int>* rootptr, AllocatorType& allocator)
{
    throw std::exception();
}

template <typename AllocatorType>
Node<int>* cloneMirror(Node<int>* rootptr, AllocatorType& allocator)
{
    throw std::exception();
}
