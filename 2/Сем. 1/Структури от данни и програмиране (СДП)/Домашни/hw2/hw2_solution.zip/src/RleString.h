#pragma once

#include <string>

class RleString {

private:

	/// Represents one node in the linked list
	class Node {
	public:
		Node* next;   /// Next node in the linked list
		size_t count; /// Number of repetitions of the symbol
		char symbol;  /// Symbol that is repeated one or more times

		Node(Node* next = nullptr, size_t count = 0, char symbol = 0);
		~Node();  /// Deletes all following nodes.

		bool operator==(const Node&) const;
		bool operator!=(const Node&) const;

		Node* returnCopy();  /// 'next' of the returned object is set to nullptr.
	};

private:
	
	Node* topNode{ nullptr };
	size_t length{ 0 };        /// Length of the string represented by this object.

public:
	/// Create an empty string, which does not allocate any resources
	RleString();

	/// Create an RLE-encoded string from the contents of str
	///
	/// If str is the empty string, this constructor creates an empty object.
	///
	RleString(const std::string& str);
	RleString(const RleString& other);
	RleString(RleString&& rvalue) noexcept;
	
	RleString& operator=(const RleString& other);
	RleString& operator=(RleString&& rvalue) noexcept;
	
	~RleString();

	/// Returns the contents of the RleString as a std::string object
	std::string toString() const;

	/// Checks whether two RleStrings objects represent the same string
	bool operator==(const RleString& other) const;

	/// Checks whether this object represents the same string as that of str
	bool operator==(const std::string& str) const;

	/// Returns the length of the string represented by this object
	/// 
	/// For example, size() returns 10 for the string "aaaaaaaaaa".
	///
	size_t size() const noexcept;

	/// Insert value at the given index in the string
	///
	/// @param index
	///   Index of the position where the insertion should take place.
	///   Must be a value between 0 and size().
	///   If index == size(), then value is appended to the string
	///
	/// @exception std::out_of_range if index > size()
	///
	void insertAt(size_t index, char value);

	/// Remove the character at index
	/// @exception std::out_of_range if index >= size()
	void removeAt(size_t index);

	/// Reverses the contents of the string
	///
	/// For example, if the object represents the string
	/// "abcdef", after reversing, it will become "fedcba".
	void reverse();

	/// Checks whether rle is a substring of this object
	///
	/// For example:
	///   - "", "a", "aa", "ab", "aab" and "aabb" are all substrings of "aabb"
	///   - "" is a substring of ""
	///   - "abc" is a substring of "abc"
	///   - "ac" is NOT a substring of "abc"
	///   - "abc" is NOT a substring of "ab"
	bool contains(const RleString& rle) const;


private:
	
	// Returns the containing node of the symbol at 'index'.
	// Returns the index of the symbol within 'containingNode'.
	// Returns the node before 'containingNode'.
	// If 'index >= this->length' returns nullptr for 'containingNode.
	void findContainingNode(size_t& index, Node*& containingNode, Node*& prevNode) const;
	
	// Returns true if the two chains of nodes represent the same string.
	bool areChainsEqual(const Node* top1, const Node* top2) const;

	size_t howManyNodes() const;

	// Throws std::bad_alloc if mem alloc fails.
	// 'prevNode' must not be nullptr.
	inline void insertAtBorderBetween2nodes(Node* prevNode, Node* containingNode, char value);

	// Throws std::bad_alloc if mem allo fails.
	// Strong exception safety.
	// 'index' must be: 0 < 'index' < containingNode->count
	inline void insertInsideOfANode(Node* containingNode, size_t index, char value);


	void copy(const RleString& other);
	void copy(RleString&& rvalue);
	void free();                        /// Deletes all nodes.
};