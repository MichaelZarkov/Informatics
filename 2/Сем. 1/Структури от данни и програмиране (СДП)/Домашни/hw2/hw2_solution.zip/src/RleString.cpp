
#include <new>         // std::nothrow
#include <stdexcept>   // std::out_of_range
#include <utility>     // std::move()
#include "RleString.h"


RleString::Node::Node(RleString::Node* next, size_t count, char symbol)
	: next(next), count(count), symbol(symbol)
{}
RleString::Node::~Node()
{
	delete next;
}
bool RleString::Node::operator==(const Node& other) const
{
	return this->count == other.count && this->symbol == other.symbol;
}
bool RleString::Node::operator!=(const Node& other) const
{
	return this->count != other.count || this->symbol != other.symbol;
}
RleString::Node* RleString::Node::returnCopy()
{
	return new(std::nothrow) Node{ nullptr, count, symbol };
}


RleString::RleString()
{}
RleString::RleString(const std::string& str)
{
	// Check if 'str' is empty.
	const char* cstr = str.c_str();
	if (!*cstr)
		return;

	// Initialize the top node.
	char symbol = *(cstr++);
	size_t count = 1;
	while (*cstr == symbol) {
		++cstr;
		++count;
	}
	topNode = new Node{ nullptr, count, symbol };
	length += count;


	Node* currNode = topNode;
	while (*cstr)
	{
		symbol = *(cstr++);
		count = 1;
		while (*cstr == symbol) {
			++cstr;
			++count;
		}

		currNode->next = new(std::nothrow) Node{ nullptr, count, symbol };
		if (!currNode->next) {
			free();
			std::bad_alloc ba;
			throw ba;
		}
		length += count;

		currNode = currNode->next;
	}
}
RleString::RleString(const RleString& other)
{
	copy(other);
}
RleString::RleString(RleString&& rvalue) noexcept
{
	copy(std::move(rvalue));
}
// Strong exception safety.
RleString& RleString::operator=(const RleString& other)
{
	if (this != &other)
	{
		RleString temp{ other };
		free();
		copy(std::move(temp));
	}

	return *this;
}
RleString& RleString::operator=(RleString&& rvalue) noexcept
{
	if (this != &rvalue)
	{
		free();
		copy(std::move(rvalue));
	}

	return *this;
}
RleString::~RleString()
{
	free();
}


std::string RleString::toString() const
{
	std::string str;
	str.reserve(this->length);   /// I can't make it work with 'resize()' and I don't know why.
	
	Node* currNode = topNode;
	while (currNode != nullptr)
	{
		for (size_t i = 0; i < currNode->count; ++i)
			str += currNode->symbol;

		currNode = currNode->next;
	}

	return str;
}
bool RleString::operator==(const RleString& other) const
{
	return areChainsEqual(this->topNode, other.topNode);
}
bool RleString::operator==(const std::string& str) const
{
	// Go through all nodes and compare the contents of each node with 'str'.
	Node* currNode = topNode;
	const char* currPosition = str.c_str();
	while (currNode != nullptr)
	{
		// Check 'currNode'
		for (size_t i = 0; i < currNode->count; ++i, ++currPosition)
			if (*currPosition != currNode->symbol)
				return false;
		
		currNode = currNode->next;
	}

	return *currPosition == 0;    // If the 0 terminating character is reached when
	                              // the end node is reached then the strings are equal.
}
size_t RleString::size() const noexcept
{
	return length;
}
// Strong exception safety.
// Throws std::bad_alloc if mem alloc fails.
void RleString::insertAt(size_t index, char value)
{
	if (index > length)
	{
		std::out_of_range oof("'insertAt()' in class 'RleString' was called with invalid index.");
		throw oof;
	}

	// Check if there are 0 nodes.
	if (topNode == nullptr)
	{
		topNode = new Node{ nullptr, 1, value };
		++this->length;
		return;
	}

	// Find the node which has to be edited and also the node before it.
	Node* containingNode;
	Node* prevNode;
	findContainingNode(index, containingNode, prevNode);

	if (index == 0)
	{
		insertAtBorderBetween2nodes(prevNode, containingNode, value);
	}
	else
	{
		insertInsideOfANode(containingNode, index, value);
	}
}
//'index' is valid if 0 <= index < length.
void RleString::removeAt(size_t index)
{
	if (index >= length)
	{
		std::out_of_range oof("'removeAt()' in class 'RleString' was called with invalid index.");
		throw oof;
	}

	--this->length;

	// Find the node which has to be edited and also the node before it.
	Node* containingNode;
	Node* prevNode;
	findContainingNode(index, containingNode, prevNode);

	// Remove at index.
	if (containingNode->count == 1)
	{
		// If the top node has to be removed.
		if (containingNode == topNode) {
			topNode = topNode->next;
			return;
		}
			
		prevNode->next = containingNode->next;
		containingNode->next = nullptr;
		delete containingNode;
	}
	else {
		--containingNode->count;
	}
}
void RleString::reverse()
{
	// Check if there are 0 nodes.
	if (topNode == nullptr)
		return;

	Node* currNode = topNode->next;
	Node* prevNode = topNode;
	prevNode->next = nullptr;
	while (currNode)
	{
		Node* nextNode = currNode->next;
		currNode->next = prevNode;
		prevNode = currNode;
		currNode = nextNode;
	}

	topNode = prevNode;
}
bool RleString::contains(const RleString& rle) const
{
	// 'rle' is with 0 nodes.
	if (!rle.topNode) {
		return true;
	}
	// 'rle' is with 1 nodes.
	else if (!rle.topNode->next)
	{
		Node* currNode = topNode;
		while (currNode)
		{
			if (rle.topNode->symbol == currNode->symbol &&
				rle.topNode->count <= currNode->count)
			{
				return true;
			}

			++currNode;
		}

		return false;
	}
	
	// 'rle' is with 2 or more nodes.
	size_t nodeCountThis = this->howManyNodes();
	size_t nodeCountRle = rle.howManyNodes();

	Node* thisCurrTop = this->topNode;
	while (nodeCountRle <= nodeCountThis)
	{
		// Check the firts node of 'rle'.
		if (rle.topNode->symbol == thisCurrTop->symbol &&
			rle.topNode->count <= thisCurrTop->count)
		{
			// Check nodes of 'rle' between firts and last.
			Node* thisCurr = thisCurrTop->next;
			Node* rleCurr = rle.topNode->next;
			while (rleCurr->next)
			{
				if (*rleCurr != *thisCurr)
					return false;

				rleCurr = rleCurr->next;
				thisCurr = thisCurr->next;
			}

			// Check last node of 'rle'.
			if (rleCurr->symbol == thisCurr->symbol &&
				rleCurr->count <= thisCurr->count)
			{
				return true;
			}
		}

		thisCurrTop = thisCurrTop->next;
		--nodeCountThis;
	}
	
	return false;
}


void RleString::findContainingNode(size_t& index, Node*& containingNode, Node*& prevNode) const
{
	containingNode = topNode;
	prevNode = topNode;
	if (containingNode && index >= containingNode->count)
	{
		index -= containingNode->count;
		containingNode = containingNode->next;
	}
	while (containingNode && index >= containingNode->count)
	{
		index -= containingNode->count;
		prevNode = containingNode;
		containingNode = containingNode->next;
	}
}
bool RleString::areChainsEqual(const Node* top1, const Node* top2) const
{
	while (top1 && top2)
	{
		if (*top1 != *top2)
			return false;

		top1 = top1->next;
		top2 = top2->next;
	}

	return top1 == top2;  // If both are nullptr return true.
}
size_t RleString::howManyNodes() const
{
	if (!topNode)
		return 0;

	const Node* currNode = topNode->next;
	size_t count = 1;
	while (currNode)
	{
		++count;
		currNode = currNode->next;
	}
	return count;
}
inline void RleString::insertAtBorderBetween2nodes(Node* prevNode, Node* containingNode, char value)
{
	// Check if 'value' is the same as the symbol in one of the adjacent nodes.
	if (value == prevNode->symbol)
	{
		++prevNode->count;
		++this->length;
		return;
	}
	if (containingNode != nullptr && value == containingNode->symbol)
	{
		++containingNode->count;
		++this->length;
		return;
	}

	// Make a new node for 'value' and insert it in the list.
	Node* toInsert = new Node{ containingNode, 1, value };
	// Check if there is only one node in the list.
	if (prevNode == containingNode)
		topNode = toInsert;
	else
		prevNode->next = toInsert;

	++this->length;
}
inline void RleString::insertInsideOfANode(Node* containingNode, size_t index, char value)
{
	// Check if the 'value' is the same as symbol in the node.
	if (value == containingNode->symbol)
	{
		++containingNode->count;
		++this->length;
		return;
	}

	// Split 'containingNode' in two and add new node with 'value' between the split nodes.
	Node* nodeAfterValue = new Node{ containingNode->next, containingNode->count - index, containingNode->symbol };
	Node* nodeWithValue = new(std::nothrow) Node{ nodeAfterValue, 1, value };
	if (!nodeWithValue)
	{
		delete nodeAfterValue;
		std::bad_alloc ba;
		throw ba;
	}
	containingNode->count = index;
	containingNode->next = nodeWithValue;
	++this->length;
}


// Throws 'std::bad_alloc' if mem alloc fails.
void RleString::copy(const RleString& other)
{   
	if (other.topNode == nullptr)
	{
		this->topNode = nullptr;
		length = 0;
		return;
	}

	// Copy the nodes.
	this->topNode = other.topNode->returnCopy();
	if (this->topNode == nullptr)
	{
		std::bad_alloc ba;
		throw ba;
	}
	Node* copyFrom = other.topNode->next;
	Node* copyTo = this->topNode;
	while (copyFrom)
	{
		copyTo->next = copyFrom->returnCopy();
		if (copyTo == nullptr)
		{
			free();
			std::bad_alloc ba;
			throw ba;
		}

		copyFrom = copyFrom->next;
		copyTo = copyTo->next;
	}

	this->length = other.length;
}
void RleString::copy(RleString&& rvalue)
{
	this->topNode = rvalue.topNode;
	this->length = rvalue.length;

	rvalue.topNode = nullptr;
	rvalue.length = 0;
}
void RleString::free()
{
	delete topNode;
}