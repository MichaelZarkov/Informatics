#pragma once

#include "Allocator.h"
#include "Node.h"

#include <stdexcept>
#include <algorithm>

// Returns the max depth of the tree.
// If the tree is not height balanced, returns -1.
template<typename T>
int isHeightBalancedRec(const Node<T>* root)
{
    if (root == nullptr)
        return 0;

    int leftHeight = isHeightBalancedRec(root->left);
    if (leftHeight == -1)
        return -1;

    int rightHeight = isHeightBalancedRec(root->right);
    if (rightHeight == -1)
        return -1;

    if (abs(leftHeight - rightHeight) > 1)
        return -1;
    
    return leftHeight > rightHeight ? leftHeight + 1 : rightHeight + 1;
}
bool isHeightBalanced(Node<int>* rootptr)
{
    return isHeightBalancedRec(rootptr) != -1;
}

template <typename AllocatorType>
void free(Node<int>* rootptr, AllocatorType& allocator)
{
    if (rootptr == nullptr)
        return;

    free(rootptr->left, allocator);
    free(rootptr->right, allocator);

    allocator.release(rootptr);
}

// Returns the pointer to the root node of a tree that is mirror image of the given one.
// Throws 'std::bad_alloc' if mem alloc fails.
// Doesn't delete the mirror tree if mem alloc fails (see 'Node<int>* cloneMirror(Node<int>*, AllocatorType&)' for the deletion).
//
// Works by traversing the original tree "left-root-right" and the mirror tree "right-root-left".
template<typename T, typename AllocatorType>
Node<T>* cloneMirrorRec(const Node<T>* rootOriginal, AllocatorType& allocator)
{
    if (rootOriginal == nullptr)
        return nullptr;

    // Alloc new node with the same data as 'rootOriginal'.
    Node<T>* newMirrorNode = allocator.buy();     // This throws 'std::bad_alloc' if mem alloc fails.
    newMirrorNode->data = rootOriginal->data;

    // Call recursively for the right and left subtrees.
    newMirrorNode->right = cloneMirrorRec(rootOriginal->left, allocator);
    newMirrorNode->left = cloneMirrorRec(rootOriginal->right, allocator);

    return newMirrorNode;
}
template <typename AllocatorType>
Node<int>* cloneMirror(Node<int>* rootptr, AllocatorType& allocator)
{
    if (rootptr == nullptr)
        return nullptr;

    // Allocation of root node is here because if mem alloc fails
    // I need the root to delete the whole tree.
    Node<int>* rootMirror = allocator.buy();
    rootMirror->data = rootptr->data;

    try
    {
        rootMirror->right = cloneMirrorRec(rootptr->left, allocator);
        rootMirror->left = cloneMirrorRec(rootptr->right, allocator);
    }
    catch (...)
    {
        free(rootMirror);
        std::bad_alloc ba;
        throw ba;
    }

    return rootMirror;
}
