#include "catch2/catch_all.hpp"
#include "Allocator.h"
#include "Node.h"

//TODO If you want to add additional tests, write them in this file

// TEST_CASE("Sample test")
// {
//     REQUIRE(true);
// }