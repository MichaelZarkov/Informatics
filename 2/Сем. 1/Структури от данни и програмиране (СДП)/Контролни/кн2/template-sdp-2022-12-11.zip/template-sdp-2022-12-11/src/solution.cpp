#include "solution.h"

#include <stdexcept>

void removeConsecutiveDuplicates(Node* first)
{
	
}

Node* cloneReversed(Node* first)
{
	return nullptr;
}